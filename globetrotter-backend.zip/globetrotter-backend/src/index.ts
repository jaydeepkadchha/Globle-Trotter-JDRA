import "dotenv/config";
import express from "express";
import cors from "cors";
import authRoutes from "./routes/auth";
import { requireAuth, AuthedRequest } from "./middleware/auth";
import { prisma } from "./lib/prisma";

const app = express();
app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => res.json({ ok: true }));

app.use("/auth", authRoutes);

// Example protected route — confirms the token flow works end to end.
// Swap this out for real trip routes next (GET/POST /trips, etc).
app.get("/me", requireAuth, async (req: AuthedRequest, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.userId },
    select: { id: true, name: true, email: true, createdAt: true },
  });
  res.json({ user });
});

const port = process.env.PORT ? Number(process.env.PORT) : 4000;
app.listen(port, () => console.log(`GlobeTrotter API running on http://localhost:${port}`));
