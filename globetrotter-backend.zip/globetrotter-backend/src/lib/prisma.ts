import { PrismaClient } from "@prisma/client";

// Reuse a single PrismaClient instance across the app instead of creating
// a new one per request (avoids exhausting DB connections in dev with hot reload).
export const prisma = new PrismaClient();
