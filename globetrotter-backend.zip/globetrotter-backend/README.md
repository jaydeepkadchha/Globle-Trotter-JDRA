# GlobeTrotter Backend — Step 1 Scaffold

This is the very first slice: project setup, database schema, and working auth
(signup/login/JWT). Everything else (trips, stops, activities, budget) builds
on top of this.

## 1. Install Postgres

Easiest path — Docker:
```bash
docker run --name globetrotter-db -e POSTGRES_PASSWORD=postgres -e POSTGRES_DB=globetrotter -p 5432:5432 -d postgres
```
Or install Postgres locally and create a `globetrotter` database.

## 2. Install dependencies
```bash
npm install
```

## 3. Configure environment
```bash
cp .env.example .env
```
Edit `.env` if your DB credentials differ, and set `JWT_SECRET` to any long random string.

## 4. Create the database tables
```bash
npm run prisma:migrate
```
This reads `prisma/schema.prisma` and creates the `User`, `Trip`, `City`, `Stop`,
`Activity`, and `TripActivity` tables in Postgres. Name the migration something
like `init` when prompted.

## 5. Run the server
```bash
npm run dev
```
Server starts on `http://localhost:4000`.

## 6. Test it
```bash
# Sign up
curl -X POST http://localhost:4000/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"name":"Raj","email":"raj@example.com","password":"password123"}'

# Copy the returned token, then call the protected route
curl http://localhost:4000/me -H "Authorization: Bearer <token>"
```

If `/me` returns your user, auth is fully wired end to end.

## What's next (in order)
1. `POST /trips`, `GET /trips` — Create Trip + My Trips screens
2. `POST /trips/:id/stops` — add a city + dates to a trip (Itinerary Builder)
3. Seed the `City` and `Activity` tables with sample data so City/Activity Search has something to return
4. `POST /stops/:id/activities` — assign an activity to a stop (still Itinerary Builder)
5. `GET /trips/:id` returning the full nested trip → stops → activities — powers Itinerary View + budget total
6. Connect the frontend prototype's Build screen to these endpoints instead of local state
